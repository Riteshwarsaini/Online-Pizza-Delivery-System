package com.app.pojos;

public enum UserRole {
CUSTOMER, DELIVERYBOY,MANAGER
}
