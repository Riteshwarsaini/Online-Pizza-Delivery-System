package com.app.pojos;

public enum EmployeeStatus {
WORKING, NOT_WORKING
}
