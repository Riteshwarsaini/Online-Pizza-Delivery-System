package com.app.pojos;

public enum Role {
ADMIN,MANAGER,DELEVERY_BOY
}
