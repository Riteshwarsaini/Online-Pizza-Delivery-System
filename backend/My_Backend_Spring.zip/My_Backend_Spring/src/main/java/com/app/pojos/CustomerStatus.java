
package com.app.pojos;

public enum CustomerStatus {
	BLOCKED, ACTIVE
}
