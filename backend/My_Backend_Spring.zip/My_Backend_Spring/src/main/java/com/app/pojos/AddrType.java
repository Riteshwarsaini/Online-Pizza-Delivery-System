
package com.app.pojos;

public enum AddrType {
	RESIDENT, OFFICE, HOME, OTHER
}
